
clear all
close all

tic

% ��������
fs = 8;                    % �˲�ǰ��������
fs2 = 4;                    % �˲����������
sampleFrequency = 125000;   % ������
winLen = 8192;              % ���ڳ���
overlapping = 128;           % �ص�����
filterLen = 1024;            % �˲�������

segment = 3;                % ��������
frameLen = winLen*segment - (segment-1)*overlapping;    % һ֡�Ĳ�������
LS = ceil(frameLen/fs);     % ������Ԫ����

frameNumber = 100;          % ֡��
SNR = [-25:1:24];             % �����

% �˲���
% h = geth(fs);
% BaseUpsamplingRateTx = 8;
% FilterRRCTx = zeros(1,6*BaseUpsamplingRateTx-1);
% tmpF = rcosdesign(0.485,6,BaseUpsamplingRateTx,'sqrt');
% figure;
% plot(tmpF);
% FilterRRCTx = tmpF(1,2:end-1)./(max(tmpF));

BaseUpsamplingRateTx = 8;
FilterSym = 6;
FilterRRCTxTmp = zeros(1,FilterSym*BaseUpsamplingRateTx);
tmpF = rcosdesign(0.485,FilterSym,BaseUpsamplingRateTx,'sqrt');
% FilterRRCTxTmp = tmpF(1,2:end-1)./(max(tmpF));
FilterRRCTxTmp = tmpF(1,1:end)./(max(tmpF));

%     FilterRRCTxTmp1 = (FilterRRCTxTmp(1,floor(length(FilterRRCTxTmp)/2))*2 + FilterRRCTxTmp(1,ceil(length(FilterRRCTxTmp)/2)))/3;
FilterRRCTxTmp1 = 1;
FilterRRCTxTmp2 = [FilterRRCTxTmp(1,1:floor(length(FilterRRCTxTmp)/2)) FilterRRCTxTmp1];
FilterRRCTxTmp3 = [FilterRRCTxTmp2 fliplr(FilterRRCTxTmp2)];

h = FilterRRCTxTmp3;
figure;
plot(h);

SNRCheck = zeros(frameNumber,length(SNR));
ECount = zeros(frameNumber,length(SNR));
SNRTable = zeros(length(SNR),3);
SNRTable(:,1) = SNR';

for ii = 1:frameNumber
    
    % ���ɷ���
%     symbols = randi([0 1],LS,1);
%     symbols(symbols==0) = -1;
%     info = symbols;
%     info(2:2:end,:) = info(2:2:end,:)*(1i);

    ModOrder = 3;
    symbolsbit = randi([0 1],1,LS*ModOrder);

    tmpM = zeros(1,LS);
    for i1=1:ModOrder
        tmpM = tmpM + 2^(ModOrder-i1)*symbolsbit(1,i1:ModOrder:end);
    end
    info(1,:) = pskmod(tmpM,2^ModOrder,0,'gray');
    
    infoup = upsample(info,fs);
    
    temp = conv(infoup,h);
    modSignal = temp(ceil(length(h)/2):end-floor(length(h)/2));
    PSK = transpose(modSignal(:));
    
%     figure;
%     plot(abs(PSK));
    
    % MSK�ź��˲�
    PSK1 = channelize20180408A(PSK, 0, overlapping, winLen, filterLen, sampleFrequency);
    PSK2 = channelize20180408C(PSK1, 0, filterLen, fs, fs2, overlapping, winLen, sampleFrequency, frameLen,1)/2;
%     PSK2 = channelize20180408C(PSK1, 0, filterLen, fs, fs2, overlapping, winLen, sampleFrequency, frameLen,1);
%     figure;
%     plot(abs(PSK2));
    
    PSKPower = PSK2*PSK2';
    
    for jj = 1:length(SNR)
        
        % ��������
        sigma = sqrt(1/(10^(SNR(jj)/10)));
        noise = sigma*(randn(1,length(PSK))+(1i)*randn(1,length(PSK)))/sqrt(2);
        
        % �����˲�
        noise1 = channelize20180408A(noise, 0, overlapping, winLen, filterLen, sampleFrequency);
        noise2 = channelize20180408C(noise1, 0, filterLen, fs, fs2, overlapping, winLen, sampleFrequency, frameLen,1)/2/0.9081;
        noisePower = noise2*noise2';
        
        SNRHat = 10*log10(PSKPower/noisePower);
        SNRCheck(ii,jj) = SNRHat;
        
%         % ����˲�ǰ��Ӻ��˲�������Ƿ���ͬ����ͬ
%         dataA = MSK + noise;
%         dataA1 = channelize20180408A(dataA, 0, overlapping, winLen, filterLen, sampleFrequency);
%         dataA2 = channelize20180408C(dataA1, 0, filterLen, fs, fs2, overlapping, winLen, sampleFrequency, frameLen,1)/2/0.9081;
%         dataB2 = MSK2 + noise2;
%         plot(real(dataA2-dataB2));
        
        % ͳ��
        data = PSK2 + noise2;
        dataAbs = abs(data);
        P = dataAbs*dataAbs'/length(dataAbs);
        dataNormal = dataAbs/sqrt(P);
        E = mean(dataNormal);
        ECount(ii,jj) = E;
 
    end

end

SNRTable(:,2) = mean(SNRCheck);
SNRTable(:,3) = mean(ECount)
PSKTable = SNRTable;
save('PSKTable.mat','PSKTable');


toc



















