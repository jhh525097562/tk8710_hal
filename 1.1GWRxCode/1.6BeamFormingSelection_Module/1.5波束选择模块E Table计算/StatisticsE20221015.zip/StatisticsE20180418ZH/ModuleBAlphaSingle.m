
clear all
close all

tic

% ��������
fs = 32;                    % �˲�ǰ��������
fs2 = 8;                    % �˲����������
sampleFrequency = 125000;   % ������
winLen = 8192;              % ���ڳ���
overlapping = 64;           % �ص�����
filterLen = 256;            % �˲�������

% ͳ�Ƹɾ����˲���MSK�ź�+��ͬ���ʵĸ���˹��������ģ�����е�ƽ������P,��������P��һ�������ֵE,����E��MSK�ź�SNR�Ķ�Ӧ����

segment = 3;                % ��������
frameLen = winLen*segment - (segment-1)*overlapping;    % һ֡�Ĳ�������
LS = ceil(frameLen/fs);     % ������Ԫ����

frameNumber = 200;          % ֡��

load('SNRTable');

M = 4;
N = 8;
SNR = -20:1:4;
supressNum = 7;             % ���Ʒ�������

PCoef = 2;                  % ���ʲ�
HCoef = sqrt(0.1);          % �ŵ��������
alpha = 0.9;               % ��ģȨ��

errSelect = zeros(length(SNR),length(alpha));
errAll = zeros(length(SNR),1);
errMMSE = zeros(length(SNR),1);

h = geth(fs);
% ����ÿһ֡����
for ii = 1:frameNumber

    symbols = randi([0 1],LS,M);
    symbols(symbols==0) = -1;
    modSignal = zeros(LS*fs,M);
    info = symbols;
    info(2:2:end,:) = info(2:2:end,:)*(1i);
    infoup = upsample(info,fs);
    for mm = 1:M
        temp = conv(infoup(:,mm),h);
        modSignal(:,mm) = temp(2*fs+1:end-2*fs+1);
    end
    MSK = transpose(modSignal);

    % �������Ƶƫ
    freq = randi([-sampleFrequency/2 sampleFrequency/2],1);
    freqInt = round(freq/sampleFrequency*winLen)/winLen*sampleFrequency;
    
    % ���ɷ����ź�
    Tx = MSK.*repmat(exp((1i)*2*pi*(0:LS*fs-1)/sampleFrequency*freqInt),M,1);
    Tx = Tx(:,1:frameLen);
    
    % �����ŵ���Ӧ
    H = (randn(N,M)+randn(N,M)*(1i))/sqrt(2)/sqrt(N);
    % �ŵ��������
    HDiff = (randn(N,M)+randn(N,M)*(1i))/sqrt(2)/sqrt(N);
    
    % ���治ͬ�����
    for jj = 1:length(SNR)
        % ��������
        sigma = sqrt(1/(10^(SNR(jj)/10)));
        % ��������
        noise = sigma*(randn(N,frameLen)+randn(N,frameLen)*(1i))/sqrt(2);
        
        % ���治ͬ���ʲ�
        for kk = 1:length(PCoef)
            if PCoef(kk) == 1
                D = eye(M);
            else
                D = diag(10.^((10+20*rand(1,M))/20));
                D(1,1) = 1;
            end
            
            % �����ź�
            Rx = H*D*Tx+noise;
            
            % ���治ͬ���ŵ����
            for ll = 1:length(HCoef)
                Hhat = (H + HCoef(ll)*HDiff)*D;
                
                % �ŵ���
                dataRec1 = channelize20180408A(Rx, repmat(freqInt,1,M), overlapping, winLen, filterLen, sampleFrequency);
                dataRec2 = channelize20180408B(dataRec1, Hhat, filterLen, N, supressNum);
                dataRec3 = channelize20180408C(dataRec2, repmat(freqInt,1,M*(supressNum+1)), filterLen, fs, fs2, overlapping, winLen, sampleFrequency, size(Rx,2),1);
                
                % ��ģ�͹���ѡ���㷨
                dataRec4 = dataRec3(1:N,:)/1.8162;

                dataRec = zeros(1,6112);
                for nn = 1:segment
                    % ��E
                    if nn == 1
                        dataAbs = abs(dataRec4(:,1:2040));
                    elseif nn == 3
                        dataAbs = abs(dataRec4(:,4072+1:4072+2040));
                    else
                        dataAbs = abs(dataRec4(:,2040+1:2040+2032));
                    end
                            
                    P = dataAbs*dataAbs'/length(dataAbs);
                    PP = diag(sqrt(P));
                    dataNormal = diag(1./PP)*dataAbs;
                    E = mean(dataNormal,2);

                    powExp = sum(abs(Hhat(:,1)).^2);

                    % ��SNR
                    select = zeros(N,length(alpha));
                    Pmsk = zeros(1,N);
                    for mm = 1:N
                        diff = abs(E(mm)-SNRTable(:,3));
                        [temp,index] = min(diff);
                        SNRSelect1 = SNRTable(index,2);
                        Pmsk(mm) = P(mm,mm)*10^(SNRSelect1/10)/(10^(SNRSelect1/10)+1);
                        select(mm,:) = alpha*(SNRSelect1) - (1-alpha)*abs(10*log10(2*Pmsk(mm)/powExp))^2;
                    end

                    [~,index] = max(select);
                    if nn == 1
                        dataRec(1:2040) = dataRec4(index,1:2040);
                    elseif nn == 3
                        dataRec(4072+1:4072+2040) = dataRec4(index,4072+1:4072+2040);
                    else
                        dataRec(2040+1:2040+2032) = dataRec4(index,2040+1:2040+2032);
                    end
                end

                
                % ����������
                MSKReal = real(MSK(1,2*fs+1:2*fs:end-fs));
                MSKImag = imag(MSK(1,fs+1:2*fs:end-fs));
                dataReal1 = real(dataRec(:,2*fs2+1:2*fs2:end-fs2));
                dataReal1(dataReal1>=0) = 1;
                dataReal1(dataReal1<0) = -1;
                dataImag1 = imag(dataRec(:,fs2+1:2*fs2:end-fs2));
                dataImag1(dataImag1>=0) = 1;
                dataImag1(dataImag1<0) = -1;
                err1 = (sum(abs(repmat(MSKReal,length(alpha),1)-dataReal1),2) + sum(abs(repmat(MSKImag,length(alpha),1)-dataImag1),2))/2;
                errSelect(jj,:) = errSelect(jj,:) + err1' / (LS-2) / frameNumber;
                
                dataRec1 = channelize20180408A(Rx, repmat(freqInt,1,M), overlapping, winLen, filterLen, sampleFrequency);
                dataRec2 = compareBest(dataRec1(1,:), filterLen, N, Hhat);
                dataRec3 = channelize20180408C(dataRec2, repmat(freqInt,1,2^supressNum), filterLen, fs, fs2, overlapping, winLen, sampleFrequency, size(Rx,2),1)/2;
                dataReal1 = real(dataRec3(:,2*fs2+1:2*fs2:end-fs2));
                dataReal1(dataReal1>=0) = 1;
                dataReal1(dataReal1<0) = -1;
                dataImag1 = imag(dataRec3(:,fs2+1:2*fs2:end-fs2));
                dataImag1(dataImag1>=0) = 1;
                dataImag1(dataImag1<0) = -1;
                errAll(jj,1) = errAll(jj,1) + min(sum(abs(repmat(MSKReal,128,1)-dataReal1),2) + sum(abs(repmat(MSKImag,128,1)-dataImag1),2))/2 / (LS-2) / frameNumber;

                RxMMSE = (Hhat'*Hhat+sigma^2*10^(-1.505)*eye(M))\Hhat'*Rx;
                dataRec1 = channelize20180408A(RxMMSE(1,:), freqInt, overlapping, winLen, filterLen, sampleFrequency);
                dataRec3 = channelize20180408C(dataRec1, repmat(freqInt,1,supressNum+1), filterLen, fs, fs2, overlapping, winLen, sampleFrequency, size(Rx,2),1)/2;
                dataReal1 = real(dataRec3(1,2*fs2+1:2*fs2:end-fs2));
                dataReal1(dataReal1>=0) = 1;
                dataReal1(dataReal1<0) = -1;
                dataImag1 = imag(dataRec3(1,fs2+1:2*fs2:end-fs2));
                dataImag1(dataImag1>=0) = 1;
                dataImag1(dataImag1<0) = -1;
                errMMSE(jj,1) = errMMSE(jj,1) +(sum(abs(MSKReal-dataReal1)) + sum(abs(MSKImag-dataImag1)))/2 / (LS-2) / frameNumber;
                
            end
        end
    end
    if mod(ii,10) == 0
        fprintf('alpha: %f, frame number: %d\n',alpha(1),ii);
    end
end

figure
semilogy(SNR,errSelect,'-ob',SNR,errAll,'-*r',SNR,errMMSE,'-*b');  legend('alpha=0.9','2^7','MMSE');    grid on;
xlabel('SNR');  ylabel('error rate');   title('error rate vs SNR under imperfect CSI');

toc



















